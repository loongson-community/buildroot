#! /bin/sh

#you can custom your action after boot in this script
#if you want to run your application after boot

