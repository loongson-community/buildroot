#! /bin/sh

#sleep 5

if [ -d /usr/lib/modules/5.10.0.lsgd ]; then
	if [ ! -e /usr/lib/modules/`uname -r` ]; then
		ln -s /usr/lib/modules/5.10.0.lsgd /usr/lib/modules/`uname -r`
	fi
fi

grep -Ev '^#|^$' /etc/modules | xargs modprobe -a &

