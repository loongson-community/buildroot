#! /bin/sh

usb_fix()
{
	if [ ! -d /tmp/usblist ]; then
		return 0
	fi
	for i in $(ls /tmp/usblist)
	do
		usb_dev=$(echo $i | cut -d '-' -f 1)
		if [ ! -e "/dev/$usb_dev" ]; then
			usb_dir=$(echo $i | cut -d '-' -f 2)
			umount /mnt/$usb_dir
			rm /tmp/usblist/$i
		fi
	done
}

usb_probe()
{
	j=1
	for i in $(ls /dev/ | grep -E "^(sd|hd)")
	do
		df | grep "/dev/$i" > /dev/null
		if [ $? -eq 0 ]; then
			continue;
		fi
		temp=$(ls -l /dev | grep "$i" | wc -l)
		if [ $temp -ne 1 ]; then
			continue
		fi
		if [ ! -d /mnt/usb$j ]; then
			mkdir /mnt/usb$j
		fi
		mount /dev/$i /mnt/usb$j > /dev/null
		mountpoint -q /mnt/usb$j
		if [ $? -eq 0 ]; then
			touch /tmp/usblist/$i-usb$j
			j=$(($j + 1))
		fi
	done
}

#sleep 5

loopp=1
mkdir -p /tmp/usblist
while [ $loopp -eq 1 ];
do
	usb_fix;
	usb_probe;
	sleep 1
done

