#!/bin/bash
set -x

test_cnt=1000
sleep_time=30

date=`date +%Y%m%d`
log_dir=/opt/log_autoreboot
log_file=$log_dir/log_$date.txt
cnt_file=$log_dir/cnt.txt


if [ ! -d $log_dir ] ; then
	mkdir -p $log_dir
fi

if [ -e $cnt_file ] ; then
	test_cnt=`cat $cnt_file`	
fi

test_cnt=$(($test_cnt - 1))
echo "$test_cnt" >$cnt_file
echo "test_cnt:$test_cnt"

if [ $test_cnt -le 0 ] ; then
	echo "end .."
else
	echo "sleep $sleep_time ..."
	sleep $sleep_time 
	date_str=`date +%Y%m%d%H%M%S`
	echo "$date_str  reboot test  $test_cnt ..." >> $log_file
	reboot
fi

set +x
