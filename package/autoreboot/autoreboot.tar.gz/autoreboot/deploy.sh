#!/bin/bash

set -x

SUDO=""
if [ -e /usr/bin/sudo ] 
then 
	SUDO=sudo
fi

$SUDO hwclock -w

dest_dir=/opt
$SUDO chmod 777  $dest_dir

$SUDO cp autoreboot.sh $dest_dir
$SUDO chmod +x $dest_dir/autoreboot.sh
$SUDO cp autoreboot.service /lib/systemd/system

$SUDO systemctl enable autoreboot

set +x
